// **************************************************************************
// File       [ primitive.cpp ]
// Author     [ littleshamoo ]
// Synopsis   [ ]
// Date       [ 2011/04/19 created ]
// **************************************************************************

#include "primitive.h"

using namespace std;
using namespace IntfNs;

